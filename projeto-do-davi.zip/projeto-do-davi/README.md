# Projeto do Davi

Projeto educacional em HTML, CSS e JavaScript para demonstrar a lógica de um perceptron simples.

## Como executar
Abra o arquivo `index.html` em um navegador. Não precisa instalar nada.

## Publicar no GitHub Pages
1. Na sua conta GitHub (`davisiratsuti`), crie um repositório público chamado `projeto-do-davi`.
2. Envie `index.html` e este `README.md` para a raiz do repositório.
3. Acesse **Settings → Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**.
5. Selecione a branch `main` e a pasta `/(root)`, depois clique em **Save**.
6. Depois que o GitHub concluir a publicação, o endereço será:
   https://davisiratsuti.github.io/projeto-do-davi/

Observação: é uma demonstração didática com pesos ilustrativos, não uma ferramenta de previsão real de notas ou desempenho.
